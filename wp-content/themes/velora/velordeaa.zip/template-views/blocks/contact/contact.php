<div class="contact">
    <div class="container">
        <div class="contact__container">
            <div class="contact__col">
                <div class="contact__info">
                    <h2 class="contact-item__title">Imate pitanje?</h2>
                    <p class="contact-item__text">Slobodno nas kontaktirajte za sva pitanja, povratne informacije ili pomoć koja vam je potrebna. Naš posvećeni tim je na raspolaganju da ponudi brzu i prilagođenu pomoć, osiguravajući da vaše iskustvo kupovine bude glatko i prijatno.</p>
                </div>
            </div>
            <div class="contact__col">
                <?php echo do_shortcode('[contact-form-7 id="3301e87" title="Kontakt forma 1"]'); ?>
            </div>
        </div>
    </div>
</div>