<div class="banner" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/_demo/contact.webp');">
    <div class="container">
        <div class="banner__content">
            <h1 class="banner__title">Kontaktirajte nas</h1>
        </div>
    </div>
</div>