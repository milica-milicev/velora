<div class="hero">
    <div class="container">
        <div class="hero__content">
            <h1 class="hero__title">Postigni savršen balans stila i komfora</h1>
            <p class="hero__text">Postigni savršen balans stila i komfora</p>
            <a class="btn btn--white" href="https://velora.rs/product-category/helanke/">Otkrijte više</a>
        </div>
    </div>
    <div class="hero__image">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/_demo/hero-1.jpg" alt="">
    </div>
</div>
