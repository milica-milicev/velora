<?php
/**
 * Template View for displaying Blocks
 *
 * @package NM_Theme
 */
?>

<div class="new-block">
	<h1>New block title</h1>
</div><!-- .new-block -->
