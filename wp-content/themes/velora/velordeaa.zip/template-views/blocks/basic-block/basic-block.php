<?php
/**
 * Template View for displaying Blocks
 *
 * @package NM_Theme
 */
?>

<div class="basic-block">
	<div class="container">
		<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/Screenshot_18.png" alt="Vesey Leggings V2">
	</div>
</div><!-- .basic-block -->
